"""Работа с базой данных: подключение и схема."""
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    id    INTEGER PRIMARY KEY,
    name  TEXT    NOT NULL,
    price REAL    NOT NULL CHECK (price >= 0),
    qty   INTEGER NOT NULL DEFAULT 0 CHECK (qty >= 0)
);
CREATE TABLE IF NOT EXISTS orders (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id    INTEGER NOT NULL REFERENCES items(id),
    qty        INTEGER NOT NULL CHECK (qty > 0),
    created_at TEXT    NOT NULL DEFAULT (date('now'))
);
CREATE INDEX IF NOT EXISTS idx_orders_item_id    ON orders(item_id);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at);
"""


def connect(path):
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    if path != ":memory:":
        conn.execute("PRAGMA journal_mode = WAL")
    return conn


def init_db(path):
    """Создаёт таблицы и индексы, если их ещё нет (безопасно вызывать повторно)."""
    conn = connect(path)
    try:
        conn.executescript(SCHEMA)
        conn.commit()
    finally:
        conn.close()
