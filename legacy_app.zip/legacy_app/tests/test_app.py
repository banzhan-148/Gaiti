import os
import random
import tempfile
import unittest
from datetime import date

import db
from app import create_app
from seed import seed


class BaseCase(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.app = create_app({"DATABASE": self.path, "TESTING": True})
        self.client = self.app.test_client()
        conn = db.connect(self.path)
        with conn:
            conn.execute("INSERT INTO items (id, name, price, qty) VALUES (1, 'Болт', 10.0, 5)")
            conn.execute("INSERT INTO items (id, name, price, qty) VALUES (2, '<b>Гайка</b>', 2.5, 0)")
            conn.executemany(
                "INSERT INTO orders (item_id, qty, created_at) VALUES (?, ?, ?)",
                [(1, 2, "2024-01-10"), (1, 3, "2024-02-10"), (2, 4, "2024-02-15")],
            )
        conn.close()

    def tearDown(self):
        for suffix in ("", "-wal", "-shm"):
            try:
                os.remove(self.path + suffix)
            except FileNotFoundError:
                pass

    def post_order(self, payload):
        return self.client.post("/api/orders", json=payload)

    def stock(self, item_id):
        conn = db.connect(self.path)
        try:
            return conn.execute("SELECT qty FROM items WHERE id = ?", (item_id,)).fetchone()[0]
        finally:
            conn.close()


class InitTests(unittest.TestCase):
    def test_empty_database_is_initialised(self):
        """Раньше пустая app.db приводила к 'no such table: items'."""
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        try:
            client = create_app({"DATABASE": path}).test_client()
            self.assertEqual(client.get("/api/items").get_json(), [])
            self.assertEqual(client.get("/").status_code, 200)
        finally:
            os.remove(path)

    def test_init_is_idempotent(self):
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        try:
            db.init_db(path)
            db.init_db(path)
        finally:
            os.remove(path)

    def test_secret_key_not_hardcoded(self):
        self.assertNotEqual(create_app({"DATABASE": ":memory:"}).config["SECRET_KEY"],
                            "super-secret-key-12345")


class IndexTests(BaseCase):
    def test_renders_items(self):
        resp = self.client.get("/")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("Болт", resp.get_data(as_text=True))

    def test_html_is_escaped(self):
        html = self.client.get("/").get_data(as_text=True)
        self.assertNotIn("<b>Гайка</b>", html)
        self.assertIn("&lt;b&gt;Гайка&lt;/b&gt;", html)

    def test_price_formatted(self):
        self.assertIn("10.00", self.client.get("/").get_data(as_text=True))


class ItemsApiTests(BaseCase):
    def test_list_with_order_counts(self):
        data = self.client.get("/api/items").get_json()
        self.assertEqual([i["id"] for i in data], [1, 2])
        self.assertEqual([i["orders"] for i in data], [2, 1])
        self.assertEqual(set(data[0]), {"id", "name", "price", "qty", "orders"})

    def test_item_without_orders_has_zero(self):
        conn = db.connect(self.path)
        with conn:
            conn.execute("INSERT INTO items (id, name, price, qty) VALUES (3, 'Шайба', 1, 1)")
        conn.close()
        data = {i["id"]: i for i in self.client.get("/api/items").get_json()}
        self.assertEqual(data[3]["orders"], 0)


class CreateOrderTests(BaseCase):
    def test_success_decrements_stock_and_sets_date(self):
        resp = self.post_order({"item_id": 1, "qty": 2})
        self.assertEqual(resp.status_code, 201)
        body = resp.get_json()
        self.assertTrue(body["ok"])
        self.assertEqual(self.stock(1), 3)
        conn = db.connect(self.path)
        row = conn.execute("SELECT created_at FROM orders WHERE id = ?", (body["order_id"],)).fetchone()
        conn.close()
        self.assertEqual(row[0], date.today().isoformat())

    def test_new_order_appears_in_report(self):
        """Раньше created_at был NULL, и заказ не попадал ни в один отчёт."""
        today = date.today().isoformat()
        self.post_order({"item_id": 1, "qty": 1})
        data = self.client.get(f"/api/report?from={today}&to={today}").get_json()
        self.assertEqual(data["total"], 1)

    def test_exact_stock_allowed_then_rejected(self):
        self.assertEqual(self.post_order({"item_id": 1, "qty": 5}).status_code, 201)
        self.assertEqual(self.stock(1), 0)
        self.assertEqual(self.post_order({"item_id": 1, "qty": 1}).status_code, 409)

    def test_insufficient_stock(self):
        resp = self.post_order({"item_id": 1, "qty": 6})
        self.assertEqual(resp.status_code, 409)
        self.assertFalse(resp.get_json()["ok"])
        self.assertEqual(self.stock(1), 5)

    def test_unknown_item(self):
        self.assertEqual(self.post_order({"item_id": 999, "qty": 1}).status_code, 404)

    def test_invalid_payloads(self):
        bad = [
            {}, {"item_id": 1}, {"qty": 1},
            {"item_id": 1, "qty": 0}, {"item_id": 1, "qty": -3},
            {"item_id": "1", "qty": 1}, {"item_id": 1, "qty": "1"},
            {"item_id": 1, "qty": 1.5}, {"item_id": True, "qty": 1},
            {"item_id": None, "qty": None}, [1, 2], "text",
        ]
        for payload in bad:
            with self.subTest(payload=payload):
                self.assertEqual(self.post_order(payload).status_code, 400)
        self.assertEqual(self.stock(1), 5)

    def test_non_json_body(self):
        resp = self.client.post("/api/orders", data="not json",
                                content_type="text/plain")
        self.assertEqual(resp.status_code, 400)

    def test_sql_injection_attempt_is_harmless(self):
        resp = self.post_order({"item_id": "1); DROP TABLE orders;--", "qty": 1})
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(len(self.client.get("/api/items").get_json()), 2)

    def test_failure_is_not_swallowed_silently(self):
        """Внутренняя ошибка даёт 500 с описанием, а не пустой ответ."""
        os.remove(self.path)
        conn = db.connect(self.path)  # пустая БД без таблиц
        conn.close()
        resp = self.post_order({"item_id": 1, "qty": 1})
        self.assertEqual(resp.status_code, 500)
        self.assertIn("error", resp.get_json())


class ReportTests(BaseCase):
    def test_full_range(self):
        data = self.client.get("/api/report").get_json()
        self.assertEqual(data["total"], 9)
        self.assertEqual(data["by_item"], {"1": 5, "2": 4})
        self.assertEqual(data["revenue"], 5 * 10.0 + 4 * 2.5)

    def test_date_range_inclusive(self):
        data = self.client.get("/api/report?from=2024-02-10&to=2024-02-15").get_json()
        self.assertEqual(data["total"], 7)
        self.assertEqual(data["by_item"], {"1": 3, "2": 4})

    def test_empty_range(self):
        data = self.client.get("/api/report?from=2030-01-01&to=2030-12-31").get_json()
        self.assertEqual(data, {"total": 0, "revenue": 0, "by_item": {}})

    def test_invalid_dates(self):
        for query in ("from=abc", "to=2024-13-40", "from=2024-1-1",
                      "from=' OR 1=1 --"):
            with self.subTest(query=query):
                self.assertEqual(self.client.get(f"/api/report?{query}").status_code, 400)

    def test_from_after_to(self):
        resp = self.client.get("/api/report?from=2024-03-01&to=2024-01-01")
        self.assertEqual(resp.status_code, 400)


class SeedTests(unittest.TestCase):
    def test_seed_creates_data_and_is_rerunnable(self):
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        try:
            self.assertEqual(seed(path, 20, 100, random.Random(1)), (20, 100))
            self.assertEqual(seed(path, 20, 100, random.Random(2)), (20, 100))
            conn = db.connect(path)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM items").fetchone()[0], 20)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0], 100)
            conn.close()
        finally:
            for s in ("", "-wal", "-shm"):
                try:
                    os.remove(path + s)
                except FileNotFoundError:
                    pass


if __name__ == "__main__":
    unittest.main()
