# legacy_app

Небольшое Flask-приложение: список товаров, заказы, отчёт по заказам.

## Запуск

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python seed.py            # необязательно: тестовые данные (удаляет текущие!)
python app.py --port 5001
```

Таблицы создаются автоматически при старте, пустая `app.db` — не проблема.

Переменные окружения: `SECRET_KEY`, `DATABASE` (путь к SQLite), `FLASK_DEBUG=1` (только для разработки).

## API

| Метод | URL | Описание |
|---|---|---|
| GET | `/` | HTML-таблица товаров |
| GET | `/api/items` | товары + число заказов |
| POST | `/api/orders` | `{"item_id": int, "qty": int>0}` → 201; 400 / 404 / 409 при ошибках |
| GET | `/api/report?from=YYYY-MM-DD&to=YYYY-MM-DD` | `total` (штук), `revenue`, `by_item` |

## Тесты

```bash
pip install -r requirements-dev.txt
pytest --cov=. --cov-report=term-missing
# или без зависимостей:
python -m unittest discover -s tests -t .
```
