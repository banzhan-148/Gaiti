# Файл секретов. В реальном проекте — .env и python-dotenv.
# Здесь — потому что в учебной среде .env создать нельзя.
#
# ⚠️ Не выкладывайте этот файл в публичный git!

# Сгенерируйте свой: python -c "import secrets; print(secrets.token_hex(32))"
SECRET_KEY = "b1ad302e4ecabccb14da5a8badf807fc0ec125c508ab7366bce2ad5875ce408d2"

# Пароль администратора — смените на свой!
ADMIN_PASSWORD = "Qwerty!2026Admin"