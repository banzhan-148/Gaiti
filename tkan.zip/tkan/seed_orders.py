"""
Генератор тестовых заказов для проверки производительности.

Запуск:  python seed_orders.py
Создаёт: 200 пользователей, 10000 заказов, ~30000 позиций, ~500 отзывов.
"""
import os
import sqlite3
import random
import time
from datetime import datetime, timedelta

from db import DB

ORDERS = 10000
USERS = 200
REVIEWS = 500

FIRST = ["Иван", "Пётр", "Сергей", "Алексей", "Дмитрий", "Николай", "Максим",
         "Анна", "Мария", "Елена", "Ольга", "Татьяна", "Наталья", "Ирина",
         "Екатерина", "Светлана", "Юлия", "Ксения", "Дарья", "Полина"]
LAST = ["Иванов", "Петров", "Сидоров", "Смирнов", "Кузнецов", "Соколов",
        "Попов", "Лебедев", "Козлов", "Новиков", "Морозов", "Волков",
        "Егоров", "Павлов", "Семёнов", "Голубев", "Виноградов", "Богданов"]
STATUSES = ["Новый", "Оплачен", "Отправлен", "Доставлен"]
STATUS_WEIGHTS = [0.15, 0.25, 0.25, 0.35]
PROMOS = ["", "", "", "", "WELCOME10", "SALE500", "VIP20"]
REVIEW_TEXTS = [
    "Отличное качество, ношу с удовольствием.",
    "Размер в размер, ткань приятная.",
    "Хорошо сидит, но цвет чуть темнее, чем на фото.",
    "Отличная вещь за свои деньги.",
    "Пришло быстро, всё понравилось.",
    "Немного большемерит, но качество хорошее.",
    "Заказываю уже второй раз — рекомендую.",
    "Не совсем то, что ожидала, но носить буду.",
    "",
]


def rnd_name():
    return f"{random.choice(LAST)} {random.choice(FIRST)}"


def rnd_phone():
    return f"+79{random.randint(100000000, 999999999)}"


def rnd_email(i):
    return f"user{i}@example.com"


def main():
    if not os.path.exists(DB):
        print(f"Нет файла {DB}. Сначала запустите app.py, чтобы он создал базу.")
        return

    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    con.execute("PRAGMA journal_mode = WAL")
    con.execute("PRAGMA synchronous = NORMAL")

    products = con.execute(
        "SELECT id, name, price, sizes, stock FROM products"
    ).fetchall()
    if not products:
        print("В таблице products нет товаров. Запустите app.py инициализировать SEED.")
        return

    print(f"В базе продуктов: {len(products)}")

    # ---- Пользователи ----
    existing_users = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    user_ids = []
    if existing_users < USERS:
        print(f"Создаю {USERS - existing_users} пользователей...")
        con.executemany(
            "INSERT INTO users(email, password_hash, name, phone) VALUES (?,?,?,?)",
            [
                (rnd_email(i), "pbkdf2_sha256$200000$deadbeef$cafebabe",
                 rnd_name(), rnd_phone())
                for i in range(existing_users + 1, USERS + 1)
            ],
        )
        con.commit()
    user_ids = [r[0] for r in con.execute("SELECT id FROM users").fetchall()]
    print(f"Пользователей в базе: {len(user_ids)}")

    # ---- Заказы ----
    print(f"Создаю {ORDERS} заказов и их позиции...")
    now = datetime.now()
    t0 = time.perf_counter()

    con.execute("BEGIN IMMEDIATE")
    try:
        for n in range(1, ORDERS + 1):
            uid = random.choice(user_ids) if random.random() > 0.1 else None
            status = random.choices(STATUSES, STATUS_WEIGHTS)[0]
            created = (now - timedelta(
                days=random.randint(0, 90),
                hours=random.randint(0, 23),
                minutes=random.randint(0, 59),
            )).strftime("%Y-%m-%d %H:%M:%S")

            n_items = random.randint(1, 5)
            chosen = random.sample(products, min(n_items, len(products)))
            total = 0
            lines = []
            for p in chosen:
                size = random.choice([s.strip() for s in p["sizes"].split(",")])
                qty = random.randint(1, 3)
                price = p["price"]
                total += price * qty
                lines.append((p["name"], size, qty, price))

            promo = random.choice(PROMOS)
            discount = 0
            if promo == "WELCOME10":
                discount = total * 10 // 100
            elif promo == "SALE500" and total >= 3000:
                discount = 500
            elif promo == "VIP20" and total >= 10000:
                discount = total * 20 // 100
            final_total = total - discount

            cur = con.execute(
                "INSERT INTO orders(name, phone, total, status, created, "
                "user_id, promo_code, discount) VALUES (?,?,?,?,?,?,?,?)",
                (rnd_name(), rnd_phone(), final_total, status, created,
                 uid, promo, discount),
            )
            oid = cur.lastrowid
            con.executemany(
                "INSERT INTO order_items(order_id, name, size, qty, price) "
                "VALUES (?,?,?,?,?)",
                [(oid, l[0], l[1], l[2], l[3]) for l in lines],
            )

            if n % 1000 == 0:
                elapsed = time.perf_counter() - t0
                print(f"  {n}/{ORDERS} — {elapsed:.1f} с")
        con.execute("COMMIT")
    except Exception as e:
        con.execute("ROLLBACK")
        raise

    elapsed = time.perf_counter() - t0
    print(f"Готово за {elapsed:.1f} с")

    # ---- Отзывы ----
    existing_reviews = con.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
    if existing_reviews < REVIEWS:
        print(f"Создаю {REVIEWS - existing_reviews} отзывов...")
        pairs = set()
        tries = 0
        added = 0
        while added < REVIEWS - existing_reviews and tries < REVIEWS * 10:
            tries += 1
            uid = random.choice(user_ids)
            p = random.choice(products)
            key = (uid, p["id"])
            if key in pairs:
                continue
            pairs.add(key)
            try:
                con.execute(
                    "INSERT INTO reviews(product_id, user_id, rating, text) "
                    "VALUES (?,?,?,?)",
                    (p["id"], uid, random.randint(1, 5), random.choice(REVIEW_TEXTS)),
                )
                added += 1
            except sqlite3.IntegrityError:
                continue
        con.commit()
        print(f"Добавлено отзывов: {added}")

    # ---- Итоги ----
    print()
    print("=" * 50)
    for tbl in ("users", "orders", "order_items", "reviews", "products"):
        cnt = con.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
        print(f"  {tbl:<14} {cnt:>8}")
    print("=" * 50)
    print(f"Размер shop.db: {os.path.getsize(DB):,} байт")

    con.close()


if __name__ == "__main__":
    main()