"""
Метрики производительности маршрутов и базы данных.
"""
import os
import time
import sqlite3
import threading
from collections import defaultdict, deque

from db import DB

_LOCK = threading.Lock()
_STARTED_AT = time.time()

_ROUTES = defaultdict(lambda: {
    "count": 0,
    "total_ms": 0.0,
    "min_ms": None,
    "max_ms": 0.0,
    "errors": 0,
    "last_status": None,
    "last_ms": None,
    "last_at": None,
})

_RECENT = deque(maxlen=100)


def record(endpoint, path, method, status, ms):
    key = endpoint or path
    with _LOCK:
        r = _ROUTES[key]
        r["count"] += 1
        r["total_ms"] += ms
        r["min_ms"] = ms if r["min_ms"] is None else min(r["min_ms"], ms)
        r["max_ms"] = max(r["max_ms"], ms)
        if status >= 500:
            r["errors"] += 1
        r["last_status"] = status
        r["last_ms"] = ms
        r["last_at"] = time.time()
        _RECENT.appendleft({
            "endpoint": key,
            "path": path,
            "method": method,
            "status": status,
            "ms": ms,
            "at": time.time(),
        })


def snapshot_routes_all(app):
    """Все зарегистрированные маршруты, объединённые с собранными метриками."""
    with _LOCK:
        snap = dict(_ROUTES)

    rows = []
    for rule in app.url_map.iter_rules():
        if rule.endpoint == "static":
            continue
        r = snap.get(rule.endpoint)
        methods = ", ".join(sorted(m for m in rule.methods
                                   if m not in ("HEAD", "OPTIONS")))
        if r and r["count"]:
            rows.append({
                "endpoint": rule.endpoint,
                "rule": str(rule),
                "methods": methods,
                "count": r["count"],
                "avg_ms": r["total_ms"] / r["count"],
                "min_ms": r["min_ms"] or 0.0,
                "max_ms": r["max_ms"] or 0.0,
                "errors": r["errors"],
                "last_status": r["last_status"],
                "last_ms": r["last_ms"] or 0.0,
                "last_at": r["last_at"],
            })
        else:
            rows.append({
                "endpoint": rule.endpoint,
                "rule": str(rule),
                "methods": methods,
                "count": 0,
                "avg_ms": 0.0,
                "min_ms": 0.0,
                "max_ms": 0.0,
                "errors": 0,
                "last_status": None,
                "last_ms": 0.0,
                "last_at": None,
            })
    rows.sort(key=lambda x: (x["count"] == 0, -x["avg_ms"]))
    return rows


def snapshot_recent(limit=30):
    with _LOCK:
        return list(_RECENT)[:limit]


def totals():
    with _LOCK:
        total = sum(r["count"] for r in _ROUTES.values())
        errors = sum(r["errors"] for r in _ROUTES.values())
        seen = sum(1 for r in _ROUTES.values() if r["count"])
    return {
        "routes": seen,
        "requests": total,
        "errors": errors,
        "uptime": time.time() - _STARTED_AT,
    }


def _size(path):
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def db_size():
    main = _size(DB)
    wal = _size(DB + "-wal")
    shm = _size(DB + "-shm")
    return {"main": main, "wal": wal, "shm": shm, "total": main + wal + shm}


def db_pragma():
    con = sqlite3.connect(DB)
    try:
        def one(q):
            row = con.execute(q).fetchone()
            return row[0] if row else None
        data = {
            "page_count": one("PRAGMA page_count"),
            "page_size": one("PRAGMA page_size"),
            "journal_mode": one("PRAGMA journal_mode"),
            "foreign_keys": one("PRAGMA foreign_keys"),
            "cache_size": one("PRAGMA cache_size"),
            "synchronous": one("PRAGMA synchronous"),
            "sqlite_version": one("SELECT sqlite_version()"),
        }
        data["used_bytes"] = (data["page_count"] or 0) * (data["page_size"] or 0)
        return data
    finally:
        con.close()


def db_tables():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    try:
        names = [r[0] for r in con.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        out = []
        for n in names:
            t0 = time.perf_counter()
            cnt = con.execute(f"SELECT COUNT(*) FROM {n}").fetchone()[0]
            ms = (time.perf_counter() - t0) * 1000
            out.append({"name": n, "rows": cnt, "ms": ms})
        return out
    finally:
        con.close()


def db_indexes():
    con = sqlite3.connect(DB)
    try:
        idx = con.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='index'").fetchone()[0]
        trg = con.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='trigger'").fetchone()[0]
        return {"indexes": idx, "triggers": trg}
    finally:
        con.close()


def db_benchmark():
    tests = [
        ("SELECT 1", "SELECT 1"),
        ("PRAGMA page_count", "PRAGMA page_count"),
        ("COUNT products", "SELECT COUNT(*) FROM products"),
        ("SELECT products LIMIT 12",
         "SELECT * FROM products ORDER BY id DESC LIMIT 12"),
        ("SELECT orders LIMIT 20",
         "SELECT * FROM orders ORDER BY id DESC LIMIT 20"),
        ("JOIN products+reviews",
         "SELECT p.id, AVG(r.rating) FROM products p "
         "LEFT JOIN reviews r ON r.product_id=p.id GROUP BY p.id LIMIT 12"),
    ]
    con = sqlite3.connect(DB)
    try:
        out = []
        for label, sql in tests:
            t0 = time.perf_counter()
            for _ in range(50):
                con.execute(sql).fetchall()
            avg = (time.perf_counter() - t0) * 1000 / 50
            out.append({"label": label, "sql": sql, "ms": avg})
        return out
    finally:
        con.close()


def db_snapshot():
    t0 = time.perf_counter()
    snap = {
        "path": DB,
        "size": db_size(),
        "pragma": db_pragma(),
        "tables": db_tables(),
        "indexes": db_indexes(),
        "benchmark": db_benchmark(),
    }
    snap["collect_ms"] = (time.perf_counter() - t0) * 1000
    return snap