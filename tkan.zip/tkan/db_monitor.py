"""
Мониторинг базы данных SQLite.

Собирает метрики: размер файла, время отклика, размеры таблиц,
настройки PRAGMA, кэш-статистику.
"""
import os
import time
import sqlite3

from db import DB


def _timed(fn):
    """Замеряет время выполнения функции в миллисекундах."""
    t0 = time.perf_counter()
    result = fn()
    return result, (time.perf_counter() - t0) * 1000


def db_size() -> dict:
    """Размер файла БД и связанных WAL/SHM файлов."""
    def _size(path):
        try:
            return os.path.getsize(path)
        except OSError:
            return 0

    main = _size(DB)
    wal = _size(DB + "-wal")
    shm = _size(DB + "-shm")
    return {
        "main": main,
        "wal": wal,
        "shm": shm,
        "total": main + wal + shm,
    }


def db_pragma() -> dict:
    """Ключевые настройки и метрики через PRAGMA."""
    con = sqlite3.connect(DB)
    try:
        def one(p):
            row = con.execute(p).fetchone()
            return row[0] if row else None
        data = {
            "page_count": one("PRAGMA page_count"),
            "page_size": one("PRAGMA page_size"),
            "journal_mode": one("PRAGMA journal_mode"),
            "foreign_keys": one("PRAGMA foreign_keys"),
            "cache_size": one("PRAGMA cache_size"),
            "synchronous": one("PRAGMA synchronous"),
            "sqlite_version": one("SELECT sqlite_version()"),
        }
        data["used_bytes"] = (data["page_count"] or 0) * (data["page_size"] or 0)
        return data
    finally:
        con.close()


def table_stats() -> list:
    """Количество строк в каждой пользовательской таблице + время запроса."""
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    try:
        names = [r[0] for r in con.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name NOT LIKE 'sqlite_%' "
            "ORDER BY name")]
        result = []
        for n in names:
            t0 = time.perf_counter()
            row = con.execute(f"SELECT COUNT(*) FROM {n}").fetchone()
            ms = (time.perf_counter() - t0) * 1000
            result.append({"name": n, "rows": row[0], "ms": ms})
        return result
    finally:
        con.close()


def index_stats() -> dict:
    """Количество индексов и триггеров."""
    con = sqlite3.connect(DB)
    try:
        idx = con.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='index'").fetchone()[0]
        trg = con.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='trigger'").fetchone()[0]
        return {"indexes": idx, "triggers": trg}
    finally:
        con.close()


def latency_benchmark() -> list:
    """Замер времени отклика для типовых запросов приложения."""
    tests = [
        ("SELECT 1", "SELECT 1"),
        ("PRAGMA page_count", "PRAGMA page_count"),
        ("SELECT COUNT(*) FROM products", "SELECT COUNT(*) FROM products"),
        ("SELECT * FROM products LIMIT 12",
         "SELECT * FROM products ORDER BY id DESC LIMIT 12"),
        ("SELECT * FROM orders LIMIT 20",
         "SELECT * FROM orders ORDER BY id DESC LIMIT 20"),
        ("JOIN products + reviews",
         "SELECT p.id, AVG(r.rating) FROM products p "
         "LEFT JOIN reviews r ON r.product_id=p.id GROUP BY p.id LIMIT 12"),
    ]
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    try:
        results = []
        for label, sql in tests:
            t0 = time.perf_counter()
            for _ in range(50):  # 50 прогонов для стабильности
                con.execute(sql).fetchall()
            avg_ms = (time.perf_counter() - t0) * 1000 / 50
            results.append({"label": label, "sql": sql, "ms": avg_ms})
        return results
    finally:
        con.close()


def collect_all() -> dict:
    """Собирает все метрики одним вызовом."""
    (size, size_ms) = _timed(db_size)
    (pragma, pragma_ms) = _timed(db_pragma)
    (tables, tables_ms) = _timed(table_stats)
    (indexes, indexes_ms) = _timed(index_stats)
    (latency, latency_ms) = _timed(latency_benchmark)
    return {
        "size": size,
        "pragma": pragma,
        "tables": tables,
        "indexes": indexes,
        "latency": latency,
        "timings": {
            "size": size_ms,
            "pragma": pragma_ms,
            "tables": tables_ms,
            "indexes": indexes_ms,
            "latency": latency_ms,
            "total": size_ms + pragma_ms + tables_ms + indexes_ms + latency_ms,
        },
        "path": DB,
    }